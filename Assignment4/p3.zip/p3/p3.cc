#include <iostream>

#include "p2pCampusHelper.h"

int main(int argc, char** argv) {

	std::cout << "Hello" << std::endl; 

}
