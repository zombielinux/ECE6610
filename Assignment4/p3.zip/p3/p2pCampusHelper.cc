#include "p2pCampusHelper.h"

#include <iostream>

using namespace ns3;

PointToPointCampusHelper::PointToPointCampusHelper(uint32_t maxInner, uint32_t maxOuter, PointToPointHelper inner, PointToPointHelper outer, Ptr<UniformRandomVariable> rnd) {

}

PointToPointCampusHelper::~PointToPointCampusHelper() {

}

